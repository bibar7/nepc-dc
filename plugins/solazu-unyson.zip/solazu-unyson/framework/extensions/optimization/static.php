<?php if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$extension = slz()->extensions->get( 'optimization' );
if ( ! is_admin() ) {
	wp_enqueue_script(
		'jquery-lazy',
		slz_get_framework_directory_uri( '/static/libs/jquery.lazy.min.js' ),
		array( 'jquery' ),
		FALSE,
		TRUE
	);
	wp_enqueue_script(
		'image-lazy-load',
		slz_get_framework_directory_uri( '/static/js/img-lazy-load.js' ),
		array( 'jquery-lazy' ),
		FALSE,
		TRUE
	);
}