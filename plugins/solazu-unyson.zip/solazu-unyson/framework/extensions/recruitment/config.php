<?php if ( ! defined( 'ABSPATH' ) ) {
	die( 'Forbidden' );
}

$cfg ['image_size'] = array (
	'large'			=> '550x350',
);