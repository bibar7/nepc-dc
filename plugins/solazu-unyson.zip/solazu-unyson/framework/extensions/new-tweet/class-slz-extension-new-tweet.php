<?php if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class SLZ_Extension_New_Tweet extends SLZ_Extension {
	
	protected function _init() {
	}

}
