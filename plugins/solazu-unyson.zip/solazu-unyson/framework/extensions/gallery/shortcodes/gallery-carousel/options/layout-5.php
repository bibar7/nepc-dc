<?php
$vc_options = array(
	
);