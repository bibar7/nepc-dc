<?php
if( $image = $model->get_featured_image( $model->html_format, $data['thumb_size'] )):
	$full_image = $model->get_feature_img_url_full();
?>
<div class="grid-item <?php echo esc_attr($model->get_post_class());?> <?php echo esc_attr($model->get_navfilter_class())?>">
	<div class="slz-block-gallery-01 style-1">
		<div class="block-image">
			<a href="<?php echo esc_url($full_image)?>" class="link fancybox-thumb" data-fancybox-group="group-<?php echo esc_attr($params['uniq_id'])?>">
				<?php echo wp_kses_post($image);?>
				<span class="direction-hover"></span>
			</a>
		</div>
	</div>
</div>
<?php endif;?>