<?php if ( ! defined( 'ABSPATH' ) ) {
	die( 'Forbidden' );
}

$cfg = array();
$cfg['enable_extension_css'] = array(
	//'test',
	);
$cfg['enable_extension_js'] = array(
	//'test',

	);
$cfg['enable_shortcodes_css'] = array(
	//'test',

	);
$cfg['extra_css'] = array(
	//'test',
);
$cfg['extra_js'] = array(
	//'test',
);