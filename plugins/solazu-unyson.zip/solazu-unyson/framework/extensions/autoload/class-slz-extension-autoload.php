<?php if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class SLZ_Extension_Autoload extends SLZ_Extension {
	protected function _init() {
	}

}
