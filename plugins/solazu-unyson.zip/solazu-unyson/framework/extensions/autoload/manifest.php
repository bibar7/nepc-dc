<?php if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$manifest = array(
	'version'       => '1.0.0',
	'display'       => false,
	'thumbnail' => slz_get_framework_directory_uri( '/extensions/autoload/static/img/autoload.jpg'),
	'standalone'    => false,
	'requirements'  => array(
	),
	// 'github_update' => 'ThemeFuse/Unyson-Shortcodes-Extension'
);
