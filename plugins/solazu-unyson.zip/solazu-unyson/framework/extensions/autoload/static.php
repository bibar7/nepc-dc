<?php if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! is_admin() ) {
	//css

	// core css
	slz_autoload_core_css();
	slz_autoload_core_shortcodes_css();
	slz_autoload_core_extra_css();
	// ******************************************************js

	slz_autoload_core_extra_js();
	slz_autoload_core_scripts();
}