<ul class="block-info">
	<?php
		echo $module->get_meta_data();
	?>
</ul>